﻿

namespace Web.Api.Models.Settings
{
    public class AuthSettings
    {
        public string SecretKey { get; set; }
    }
}
