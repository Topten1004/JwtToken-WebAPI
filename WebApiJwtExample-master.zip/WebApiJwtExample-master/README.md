# WebApiJwtExample
Example of a Web Api built using ASP.NET Core secured with JWT tokens

To find out more about using JSON Web Tokens in ASP.NET Core read the [blog post for which this repo is the sample project](http://www.blinkingcaret.com/2017/09/06/secure-web-api-in-asp-net-core/).
