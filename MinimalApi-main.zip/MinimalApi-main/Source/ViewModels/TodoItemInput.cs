﻿namespace MinimalApi.ViewModels;

public class TodoItemInput
{
    public string? Title { get; set; }
    public bool IsCompleted { get; set; }
}
